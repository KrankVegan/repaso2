// Las interfaces siempre comienzan en Mayusculas, en este caso Articulo

export interface Articulo {
    body: string,
    id: number,
    title: string,
    userId: string
}
